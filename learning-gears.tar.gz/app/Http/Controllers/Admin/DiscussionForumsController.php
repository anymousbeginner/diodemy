<?php

namespace App\Http\Controllers\Admin;

use App\DiscussionForum;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreDiscussionForumsRequest;
use App\Http\Requests\Admin\UpdateDiscussionForumsRequest;
use Yajra\Datatables\Datatables;

class DiscussionForumsController extends Controller
{
    /**
     * Display a listing of DiscussionForum.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (! Gate::allows('discussion_forum_access')) {
            return abort(401);
        }


        
        if (request()->ajax()) {
            $query = DiscussionForum::query();
            $query->with("lesson");
            $query->with("course");
            $query->with("student");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
        if (! Gate::allows('discussion_forum_delete')) {
            return abort(401);
        }
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'discussion_forums.id',
                'discussion_forums.lesson_id',
                'discussion_forums.course_id',
                'discussion_forums.title',
                'discussion_forums.content',
                'discussion_forums.replies',
                'discussion_forums.date_created',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'discussion_forum_';
                $routeKey = 'admin.discussion_forums';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('lesson.title', function ($row) {
                return $row->lesson ? $row->lesson->title : '';
            });
            $table->editColumn('course.title', function ($row) {
                return $row->course ? $row->course->title : '';
            });
            $table->editColumn('student.title', function ($row) {
                if(count($row->student) == 0) {
                    return '';
                }

                return '<span class="label label-info label-many">' . implode('</span><span class="label label-info label-many"> ',
                        $row->student->pluck('title')->toArray()) . '</span>';
            });
            $table->editColumn('title', function ($row) {
                return $row->title ? $row->title : '';
            });
            $table->editColumn('content', function ($row) {
                return $row->content ? $row->content : '';
            });
            $table->editColumn('replies', function ($row) {
                return $row->replies ? $row->replies : '';
            });
            $table->editColumn('date_created', function ($row) {
                return $row->date_created ? $row->date_created : '';
            });

            

            return $table->make(true);
        }

        return view('admin.discussion_forums.index');
    }

    /**
     * Show the form for creating new DiscussionForum.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (! Gate::allows('discussion_forum_create')) {
            return abort(401);
        }
        
        $lessons = \App\Lesson::get()->pluck('title', 'id')->prepend(trans('quickadmin.qa_please_select'), '');
        $courses = \App\Course::get()->pluck('title', 'id')->prepend(trans('quickadmin.qa_please_select'), '');
        $students = \App\Role::get()->pluck('title', 'id');


        return view('admin.discussion_forums.create', compact('lessons', 'courses', 'students'));
    }

    /**
     * Store a newly created DiscussionForum in storage.
     *
     * @param  \App\Http\Requests\StoreDiscussionForumsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreDiscussionForumsRequest $request)
    {
        if (! Gate::allows('discussion_forum_create')) {
            return abort(401);
        }
        $discussion_forum = DiscussionForum::create($request->all());
        $discussion_forum->student()->sync(array_filter((array)$request->input('student')));



        return redirect()->route('admin.discussion_forums.index');
    }


    /**
     * Show the form for editing DiscussionForum.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (! Gate::allows('discussion_forum_edit')) {
            return abort(401);
        }
        
        $lessons = \App\Lesson::get()->pluck('title', 'id')->prepend(trans('quickadmin.qa_please_select'), '');
        $courses = \App\Course::get()->pluck('title', 'id')->prepend(trans('quickadmin.qa_please_select'), '');
        $students = \App\Role::get()->pluck('title', 'id');


        $discussion_forum = DiscussionForum::findOrFail($id);

        return view('admin.discussion_forums.edit', compact('discussion_forum', 'lessons', 'courses', 'students'));
    }

    /**
     * Update DiscussionForum in storage.
     *
     * @param  \App\Http\Requests\UpdateDiscussionForumsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateDiscussionForumsRequest $request, $id)
    {
        if (! Gate::allows('discussion_forum_edit')) {
            return abort(401);
        }
        $discussion_forum = DiscussionForum::findOrFail($id);
        $discussion_forum->update($request->all());
        $discussion_forum->student()->sync(array_filter((array)$request->input('student')));



        return redirect()->route('admin.discussion_forums.index');
    }


    /**
     * Display DiscussionForum.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (! Gate::allows('discussion_forum_view')) {
            return abort(401);
        }
        $discussion_forum = DiscussionForum::findOrFail($id);

        return view('admin.discussion_forums.show', compact('discussion_forum'));
    }


    /**
     * Remove DiscussionForum from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (! Gate::allows('discussion_forum_delete')) {
            return abort(401);
        }
        $discussion_forum = DiscussionForum::findOrFail($id);
        $discussion_forum->delete();

        return redirect()->route('admin.discussion_forums.index');
    }

    /**
     * Delete all selected DiscussionForum at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if (! Gate::allows('discussion_forum_delete')) {
            return abort(401);
        }
        if ($request->input('ids')) {
            $entries = DiscussionForum::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore DiscussionForum from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        if (! Gate::allows('discussion_forum_delete')) {
            return abort(401);
        }
        $discussion_forum = DiscussionForum::onlyTrashed()->findOrFail($id);
        $discussion_forum->restore();

        return redirect()->route('admin.discussion_forums.index');
    }

    /**
     * Permanently delete DiscussionForum from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        if (! Gate::allows('discussion_forum_delete')) {
            return abort(401);
        }
        $discussion_forum = DiscussionForum::onlyTrashed()->findOrFail($id);
        $discussion_forum->forceDelete();

        return redirect()->route('admin.discussion_forums.index');
    }
}
