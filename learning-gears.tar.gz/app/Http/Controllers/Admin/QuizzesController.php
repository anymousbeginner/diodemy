<?php

namespace App\Http\Controllers\Admin;

use App\Quiz;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreQuizzesRequest;
use App\Http\Requests\Admin\UpdateQuizzesRequest;
use Yajra\Datatables\Datatables;

class QuizzesController extends Controller
{
    /**
     * Display a listing of Quiz.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (! Gate::allows('quiz_access')) {
            return abort(401);
        }


        
        if (request()->ajax()) {
            $query = Quiz::query();
            $query->with("course");
            $query->with("lesson");
            $query->with("questions");
            $template = 'actionsTemplate';
            if(request('show_deleted') == 1) {
                
        if (! Gate::allows('quiz_delete')) {
            return abort(401);
        }
                $query->onlyTrashed();
                $template = 'restoreTemplate';
            }
            $query->select([
                'quizzes.id',
                'quizzes.course_id',
                'quizzes.lesson_id',
                'quizzes.title',
                'quizzes.description',
                'quizzes.published',
            ]);
            $table = Datatables::of($query);

            $table->setRowAttr([
                'data-entry-id' => '{{$id}}',
            ]);
            $table->addColumn('massDelete', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            $table->editColumn('actions', function ($row) use ($template) {
                $gateKey  = 'quiz_';
                $routeKey = 'admin.quizzes';

                return view($template, compact('row', 'gateKey', 'routeKey'));
            });
            $table->editColumn('course.title', function ($row) {
                return $row->course ? $row->course->title : '';
            });
            $table->editColumn('lesson.title', function ($row) {
                return $row->lesson ? $row->lesson->title : '';
            });
            $table->editColumn('title', function ($row) {
                return $row->title ? $row->title : '';
            });
            $table->editColumn('description', function ($row) {
                return $row->description ? $row->description : '';
            });
            $table->editColumn('questions.question', function ($row) {
                if(count($row->questions) == 0) {
                    return '';
                }

                return '<span class="label label-info label-many">' . implode('</span><span class="label label-info label-many"> ',
                        $row->questions->pluck('question')->toArray()) . '</span>';
            });
            $table->editColumn('published', function ($row) {
                return \Form::checkbox("published", 1, $row->published == 1, ["disabled"]);
            });

            

            return $table->make(true);
        }

        return view('admin.quizzes.index');
    }

    /**
     * Show the form for creating new Quiz.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (! Gate::allows('quiz_create')) {
            return abort(401);
        }
        
        $courses = \App\Course::get()->pluck('title', 'id')->prepend(trans('quickadmin.qa_please_select'), '');
        $lessons = \App\Lesson::get()->pluck('title', 'id')->prepend(trans('quickadmin.qa_please_select'), '');
        $questions = \App\Question::get()->pluck('question', 'id');


        return view('admin.quizzes.create', compact('courses', 'lessons', 'questions'));
    }

    /**
     * Store a newly created Quiz in storage.
     *
     * @param  \App\Http\Requests\StoreQuizzesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreQuizzesRequest $request)
    {
        if (! Gate::allows('quiz_create')) {
            return abort(401);
        }
        $quiz = Quiz::create($request->all());
        $quiz->questions()->sync(array_filter((array)$request->input('questions')));



        return redirect()->route('admin.quizzes.index');
    }


    /**
     * Show the form for editing Quiz.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (! Gate::allows('quiz_edit')) {
            return abort(401);
        }
        
        $courses = \App\Course::get()->pluck('title', 'id')->prepend(trans('quickadmin.qa_please_select'), '');
        $lessons = \App\Lesson::get()->pluck('title', 'id')->prepend(trans('quickadmin.qa_please_select'), '');
        $questions = \App\Question::get()->pluck('question', 'id');


        $quiz = Quiz::findOrFail($id);

        return view('admin.quizzes.edit', compact('quiz', 'courses', 'lessons', 'questions'));
    }

    /**
     * Update Quiz in storage.
     *
     * @param  \App\Http\Requests\UpdateQuizzesRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateQuizzesRequest $request, $id)
    {
        if (! Gate::allows('quiz_edit')) {
            return abort(401);
        }
        $quiz = Quiz::findOrFail($id);
        $quiz->update($request->all());
        $quiz->questions()->sync(array_filter((array)$request->input('questions')));



        return redirect()->route('admin.quizzes.index');
    }


    /**
     * Display Quiz.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (! Gate::allows('quiz_view')) {
            return abort(401);
        }
        $quiz = Quiz::findOrFail($id);

        return view('admin.quizzes.show', compact('quiz'));
    }


    /**
     * Remove Quiz from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (! Gate::allows('quiz_delete')) {
            return abort(401);
        }
        $quiz = Quiz::findOrFail($id);
        $quiz->delete();

        return redirect()->route('admin.quizzes.index');
    }

    /**
     * Delete all selected Quiz at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if (! Gate::allows('quiz_delete')) {
            return abort(401);
        }
        if ($request->input('ids')) {
            $entries = Quiz::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore Quiz from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        if (! Gate::allows('quiz_delete')) {
            return abort(401);
        }
        $quiz = Quiz::onlyTrashed()->findOrFail($id);
        $quiz->restore();

        return redirect()->route('admin.quizzes.index');
    }

    /**
     * Permanently delete Quiz from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        if (! Gate::allows('quiz_delete')) {
            return abort(401);
        }
        $quiz = Quiz::onlyTrashed()->findOrFail($id);
        $quiz->forceDelete();

        return redirect()->route('admin.quizzes.index');
    }
}
