<?php

$factory->define(App\DiscussionForum::class, function (Faker\Generator $faker) {
    return [
        "lesson_id" => factory('App\Lesson')->create(),
        "course_id" => factory('App\Course')->create(),
        "title" => $faker->name,
        "content" => $faker->name,
        "replies" => $faker->name,
        "date_created" => $faker->date("d-m-Y H:i:s", $max = 'now'),
    ];
});
