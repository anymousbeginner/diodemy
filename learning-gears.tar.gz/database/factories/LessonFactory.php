<?php

$factory->define(App\Lesson::class, function (Faker\Generator $faker) {
    return [
        "title" => $faker->name,
        "slug" => $faker->name,
        "short_text" => $faker->name,
        "full_text" => $faker->name,
        "position" => $faker->randomNumber(2),
        "free_lesson" => 1,
        "published" => 0,
    ];
});
