<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create5bc70705168e3DiscussionForumRoleTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('discussion_forum_role')) {
            Schema::create('discussion_forum_role', function (Blueprint $table) {
                $table->integer('discussion_forum_id')->unsigned()->nullable();
                $table->foreign('discussion_forum_id', 'fk_p_219714_219682_role_d_5bc7070516ab2')->references('id')->on('discussion_forums')->onDelete('cascade');
                $table->integer('role_id')->unsigned()->nullable();
                $table->foreign('role_id', 'fk_p_219682_219714_discus_5bc7070516ba4')->references('id')->on('roles')->onDelete('cascade');
                
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('discussion_forum_role');
    }
}
