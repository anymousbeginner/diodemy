<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1539770115DiscussionForumsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('discussion_forums', function (Blueprint $table) {
            if(Schema::hasColumn('discussion_forums', 'post_id')) {
                $table->dropForeign('219714_5bc702b348d24');
                $table->dropIndex('219714_5bc702b348d24');
                $table->dropColumn('post_id');
            }
            
        });
Schema::table('discussion_forums', function (Blueprint $table) {
            
if (!Schema::hasColumn('discussion_forums', 'title')) {
                $table->string('title')->nullable();
                }
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('discussion_forums', function (Blueprint $table) {
            $table->dropColumn('title');
            
        });
Schema::table('discussion_forums', function (Blueprint $table) {
                        
        });

    }
}
