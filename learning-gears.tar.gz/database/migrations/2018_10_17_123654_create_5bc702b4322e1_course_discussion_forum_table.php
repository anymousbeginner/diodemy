<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create5bc702b4322e1CourseDiscussionForumTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('course_discussion_forum')) {
            Schema::create('course_discussion_forum', function (Blueprint $table) {
                $table->integer('course_id')->unsigned()->nullable();
                $table->foreign('course_id', 'fk_p_219703_219714_discus_5bc702b4323ec')->references('id')->on('courses')->onDelete('cascade');
                $table->integer('discussion_forum_id')->unsigned()->nullable();
                $table->foreign('discussion_forum_id', 'fk_p_219714_219703_course_5bc702b432489')->references('id')->on('discussion_forums')->onDelete('cascade');
                
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('course_discussion_forum');
    }
}
