<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5bc702b4343d7RelationshipsToDiscussionForumTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('discussion_forums', function(Blueprint $table) {
            if (!Schema::hasColumn('discussion_forums', 'post_id')) {
                $table->integer('post_id')->unsigned()->nullable();
                $table->foreign('post_id', '219714_5bc702b348d24')->references('id')->on('users')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('discussion_forums', function(Blueprint $table) {
            
        });
    }
}
