<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5bc7070631c61RelationshipsToDiscussionForumTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('discussion_forums', function(Blueprint $table) {
            if (!Schema::hasColumn('discussion_forums', 'lesson_id')) {
                $table->integer('lesson_id')->unsigned()->nullable();
                $table->foreign('lesson_id', '219714_5bc707052a1f5')->references('id')->on('lessons')->onDelete('cascade');
                }
                if (!Schema::hasColumn('discussion_forums', 'course_id')) {
                $table->integer('course_id')->unsigned()->nullable();
                $table->foreign('course_id', '219714_5bc707053ea90')->references('id')->on('courses')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('discussion_forums', function(Blueprint $table) {
            
        });
    }
}
