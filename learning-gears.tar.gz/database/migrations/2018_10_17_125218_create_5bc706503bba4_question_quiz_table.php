<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create5bc706503bba4QuestionQuizTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if(! Schema::hasTable('question_quiz')) {
            Schema::create('question_quiz', function (Blueprint $table) {
                $table->integer('question_id')->unsigned()->nullable();
                $table->foreign('question_id', 'fk_p_219717_219725_quiz_q_5bc706503bd6c')->references('id')->on('questions')->onDelete('cascade');
                $table->integer('quiz_id')->unsigned()->nullable();
                $table->foreign('quiz_id', 'fk_p_219725_219717_questi_5bc706503be64')->references('id')->on('quizzes')->onDelete('cascade');
                
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('question_quiz');
    }
}
