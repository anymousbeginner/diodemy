<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Drop5bc70704215025bc707041e171CourseDiscussionForumTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('course_discussion_forum');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if(! Schema::hasTable('course_discussion_forum')) {
            Schema::create('course_discussion_forum', function (Blueprint $table) {
                $table->increments('id');
                $table->integer('course_id')->unsigned()->nullable();
            $table->foreign('course_id', 'fk_p_219703_219714_discus_5bc702b32fddd')->references('id')->on('courses');
                $table->integer('discussion_forum_id')->unsigned()->nullable();
            $table->foreign('discussion_forum_id', 'fk_p_219714_219703_course_5bc702b330a4c')->references('id')->on('discussion_forums');
                
                $table->timestamps();
                $table->softDeletes();
            });
        }
    }
}
